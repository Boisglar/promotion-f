export const chempOne = [
    { 
        id: 1,
        image: "https://disk.yandex.ru/i/lDZDu3yZFQYjSQ "
    },
    { 
        id: 2,
        image: "https://disk.yandex.ru/i/XAMSwetilbipNw "
    },
    { 
        id: 3,
        image: "https://disk.yandex.ru/i/xSz0gyw8bUz_7g" 
    },
    {
        id: 4,
        image: "https://disk.yandex.ru/i/lJ_8usMb2ZwfaA"
    }
    
]

export const chempTwo = [
    {
        id: 5,
        image: "https://disk.yandex.ru/i/mNu9_lgVxo4XRg"
    },
    {
        id: 6,
        image: "https://disk.yandex.ru/i/lcjluYVlz7dvsQ"
    },
    {
        id: 7,
        image: "https://disk.yandex.ru/i/A11ZyoAEs4P3-w"
    },
    {
        id: 8,
        image: "https://disk.yandex.ru/i/Yinmnc2LeY7E-Q"
    }
]


export const gallery = [
    { 
        id: 1,
        image: "https://disk.yandex.ru/i/lDZDu3yZFQYjSQ "
    },
    { 
        id: 2,
        image: "https://disk.yandex.ru/i/XAMSwetilbipNw "
    },
    { 
        id: 3,
        image: "https://disk.yandex.ru/i/xSz0gyw8bUz_7g" 
    },
    {
        id: 4,
        image: "https://disk.yandex.ru/i/lJ_8usMb2ZwfaA"
    },
    {
        id: 5,
        image: "https://disk.yandex.ru/i/mNu9_lgVxo4XRg"
    },
    {
        id: 6,
        image: "https://disk.yandex.ru/i/lcjluYVlz7dvsQ"
    },
    {
        id: 7,
        image: "https://disk.yandex.ru/i/A11ZyoAEs4P3-w"
    },
    {
        id: 8,
        image: "https://disk.yandex.ru/i/Yinmnc2LeY7E-Q"
    },
    {
        id: 9,
        image: "https://disk.yandex.ru/i/rQ8GObKr85ucvg"
    },
    {
        id: 10,
        image: "https://disk.yandex.ru/i/wEuz6u6g2g3ZQQ"
    },
    {
        id: 11,
        image: "https://disk.yandex.ru/i/C4QIDtSWFOxEjA"
    },
    {
        id: 12,
        image: "https://disk.yandex.ru/i/7Cf2rtlkLNsk9w"
    },
    {
        id: 13,
        image: "https://disk.yandex.ru/i/CU98OG81GdHobA"
    },
    {
        id: 14,
        image: "https://disk.yandex.ru/i/sQ54jYgSRBHutg"
    },
    {
        id: 15,
        image: "https://disk.yandex.ru/i/Trt1vpLoMYH-1g"
    },
    {
        id: 16,
        image: "https://disk.yandex.ru/i/s81kGFD9pzw5wg"
    },
    {
        id: 17,
        image: "https://disk.yandex.ru/i/o7409OamXfpZYA"
    },
    {
        id: 17,
        image: "https://disk.yandex.ru/i/pZAIcL-q9Q3CAg"
    }
]