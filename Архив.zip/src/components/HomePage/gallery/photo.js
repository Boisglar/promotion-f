import React from 'react'

export default function Photo() {
  return (
    <div>
        
    </div>
  )
}
